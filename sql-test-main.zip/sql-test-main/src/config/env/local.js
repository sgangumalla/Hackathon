module.exports = {
    sqlServer: {
        url: 'localhost',
        userName: 'sa',
        password: 'reallyStrongPwd123',
        databaseName: 'm&t',
        schemaName: 'serverInfo',
        tableName: 'FCCServerList'
    }
}
